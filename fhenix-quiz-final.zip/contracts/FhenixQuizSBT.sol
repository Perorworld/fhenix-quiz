// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {Base64} from "@openzeppelin/contracts/utils/Base64.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";
import {FHE, euint8, externalEuint8} from "@fhenixprotocol/cofhe-contracts/FHE.sol";

/// Fhenix Privacy Quiz soulbound badge (ERC-5192). Non-transferable, one per wallet.
/// The score is stored as an encrypted euint8; only the badge owner can decrypt it.
contract FhenixQuizSBT is ERC721 {
    error Soulbound();
    event Locked(uint256 tokenId);

    uint256 private _nextId;
    mapping(uint256 => euint8) private _score;
    mapping(address => bool) public hasBadge;

    event BadgeMinted(address indexed recipient, uint256 tokenId);

    string public imageURI;

    constructor(string memory badgeImageURI) ERC721("Fhenix Privacy Quiz Badge", "FPQB") {
        imageURI = badgeImageURI;
    }

    /// @param encryptedScore ciphertext handle from @cofhe/sdk encryptInputs (first item)
    /// @param signature      batch signature from @cofhe/sdk encryptInputs (last item)
    function mintBadge(externalEuint8 encryptedScore, bytes calldata signature) external returns (uint256 id) {
        require(!hasBadge[msg.sender], "Badge already minted");
        euint8 s = FHE.asEuint8(encryptedScore, signature);
        FHE.allowThis(s);          // the contract keeps access
        FHE.allow(s, msg.sender);  // the minter can decrypt their own score

        id = ++_nextId;
        hasBadge[msg.sender] = true;
        _score[id] = s;
        _mint(msg.sender, id);
        emit BadgeMinted(msg.sender, id);
        emit Locked(id);
    }

    /// ERC-5192: every token is permanently locked
    function locked(uint256 tokenId) external view returns (bool) {
        _requireOwned(tokenId);
        return true;
    }

    /// Blocks every transfer after the initial mint (also blocks burns)
    function _update(address to, uint256 tokenId, address auth) internal override returns (address) {
        if (_ownerOf(tokenId) != address(0)) revert Soulbound();
        return super._update(to, tokenId, auth);
    }

    function supportsInterface(bytes4 id) public view override returns (bool) {
        return id == 0xb45a3c0e || super.supportsInterface(id);
    }

    function getEncryptedScore(uint256 tokenId) external view returns (euint8) {
        _requireOwned(tokenId);
        return _score[tokenId];
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        string memory id = Strings.toString(tokenId);
        // The score stays private: it is an FHE ciphertext only the owner can decrypt.
        // Every badge shows the same award image; the id is what makes each token unique.
        string memory json = string.concat(
            '{"name":"Fhenix Privacy Quiz Badge #', id,
            '","description":"Quiz Master Award. Soulbound participation badge for the Fhenix Privacy Quiz. The holder\'s score is stored onchain as an FHE ciphertext only they can decrypt.","image":"',
            imageURI, '"}'
        );
        return string.concat("data:application/json;base64,", Base64.encode(bytes(json)));
    }
}
