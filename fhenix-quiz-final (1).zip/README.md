# Fhenix Privacy Quiz: full guide

## Files (keep this structure)
index.html, mint.bundle.js, tfhe_bg.wasm, package.json  (all in the repo root)
api/og.js, api/share.js, api/lb.js
contracts/FhenixQuizSBT.sol  (already deployed; kept for reference)

## 1. GitHub
1. Create a repo (or open your existing one) and delete the old files.
2. Upload everything from this folder, keeping the structure above.
3. Commit.

## 2. Vercel
1. vercel.com > Add New > Project > import the repo > Deploy.
2. Open the project > Storage > Create > Upstash Redis (free) > Connect to project.
3. Deployments > Redeploy (so the storage is picked up).

## 3. Test (needs Arbitrum Sepolia test ETH)
1. Open your Vercel link and play the quiz.
2. Click MINT SOULBOUND BADGE and confirm in the wallet. Open the transaction link.
3. Click SHARE ON X. The preview should show your score card with the quiz link.

## Already set
Badge contract (Arbitrum Sepolia): 0x61312d1338Ad15D237a317004c1b60304CEe3975
Tweets tag @fhenix.

## If something fails
Mint error: press F12 > Console, copy the red error and send it.
No card preview: X caches, so try again with a different score.
Leaderboard says "THIS DEVICE ONLY": Redis is not connected or you did not redeploy.
